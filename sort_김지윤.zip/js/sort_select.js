$(function () {
  $("select").on("change", function () {
    const ab = $(this).val();          // case0 | case1 | case2 | case3
    const n  = ab.substr(4, 1);        // '0','1','2','3'
    const $lis = $("#content ul li");  // 선택자 수정 (ul<li -> ul li)

    if (n === '0') {                   // 초기화(페이지 리로드)
      location.reload();
      return;
    }

    // jQuery 객체 -> DOM 배열로 변환 후 sort
    const sort = $lis.get().sort(function (a, b) {
      const $a = $(a), $b = $(b);

      if (n === '1') { // 최신순(날짜 내림차순)
        const da = new Date($a.find("span.date").text().trim());
        const db = new Date($b.find("span.date").text().trim());
        return db - da;
      } else if (n === '2') { // 높은가격(내림차순)
        const pa = parseInt($a.find("span.price").text().replace(/[^0-9]/g,''), 10) || 0;
        const pb = parseInt($b.find("span.price").text().replace(/[^0-9]/g,''), 10) || 0;
        return pb - pa;
      } else { // '3' 낮은가격(오름차순)
        const pa = parseInt($a.find("span.price").text().replace(/[^0-9]/g,''), 10) || 0;
        const pb = parseInt($b.find("span.price").text().replace(/[^0-9]/g,''), 10) || 0;
        return pa - pb;
      }
    });

    $("#content ul").empty().append(sort); // 정렬 반영
  });
});
