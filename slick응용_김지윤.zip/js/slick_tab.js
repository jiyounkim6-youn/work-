$(function(){
  var $slider = $('#store22');
  $slider.slick({
    slidesToShow: 3, slidesToScroll: 3, dots: true, arrows: true, infinite: false,
    speed: 350,
    responsive: [
      { breakpoint: 1024, settings: { slidesToShow: 3, slidesToScroll: 3 } },
      { breakpoint: 900,  settings: { slidesToShow: 2, slidesToScroll: 2 } },
      { breakpoint: 600,  settings: { slidesToShow: 1, slidesToScroll: 1 } }
    ]
  });

  function setActive($btn){
    $('.slick-buttons a').removeClass('active');
    $btn.addClass('active');
  }

  $('.slick-buttons').on('click','a', function(e){
    e.preventDefault();
    var key = $(this).data('filter'); 
    $slider.slick('slickUnfilter');

    if (key !== 'all') {
      $slider.slick('slickFilter','.'+ key);
      if ($slider.find('li.'+key).length === 0) {
        console.warn('[slick] no items for .' + key);
      }
    }
    setActive($(this));
  });
});