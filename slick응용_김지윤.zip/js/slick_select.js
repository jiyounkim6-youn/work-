$(function(){
  var $slider = $('#store22');
  $slider.slick({
    slidesToShow: 3, slidesToScroll: 3, dots: true, arrows: true, infinite: false,
    speed: 350,
    responsive: [
      { breakpoint: 1024, settings: { slidesToShow: 3, slidesToScroll: 3 } },
      { breakpoint: 900,  settings: { slidesToShow: 2, slidesToScroll: 2 } },
      { breakpoint: 600,  settings: { slidesToShow: 1, slidesToScroll: 1 } }
    ]
  });

  function setActiveButtonByKey(key){
    var $btns = $('.slick-buttons a');
    if(!$btns.length) return; // 버튼이 없으면 패스
    $btns.removeClass('active');
    var $target = (key === 'all')
      ? $btns.filter('[data-filter="all"], .all')
      : $btns.filter('[data-filter="'+key+'"], .' + key);
    if($target.length) $target.addClass('active');
  }

  // 유틸: select 값 설정 (있을 때만)
  function setSelectByKey(key){
    var $sel = $('#catSelect');
    if(!$sel.length) return;
    $sel.val(key);
  }

  // 공통 필터 함수
  function applyFilter(key){
    $slider.slick('slickUnfilter');
    if (key !== 'all') {
      $slider.slick('slickFilter','.'+ key);
    }
    setActiveButtonByKey(key);
    setSelectByKey(key);
  }

  // 1) 셀렉트 변경 → 필터
  $('#catSelect').on('change', function(){
    var key = $(this).val();            // all | imac | ipad | iphone | watch
    applyFilter(key);
  });

  // 2) (선택) 기존 버튼이 남아있는 경우 → 셀렉트와 동기화
  $('.slick-buttons').on('click','a', function(e){
    e.preventDefault();
    var key = $(this).data('filter') || 'all';
    applyFilter(key);
  });

  // 초기 상태(원하면 'all' 말고 특정 키로 시작 가능)
  setSelectByKey('all');
  setActiveButtonByKey('all');
});